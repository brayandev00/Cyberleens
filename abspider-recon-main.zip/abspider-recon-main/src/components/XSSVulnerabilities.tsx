import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Shield, Code, Lightbulb } from 'lucide-react';
import ModuleCardWrapper from './ModuleCardWrapper'; // Import the new wrapper

interface XSSVulnerabilitiesProps {
  xss?: {
    vulnerable: boolean;
    testedPayloads: number;
    vulnerabilities: Array<{
      payload: string;
      location: string;
      severity: 'critical' | 'high' | 'medium' | 'low'; // Updated severity types
      type?: string;
      evidence?: string;
    }>;
    tested: boolean;
  };
  isTested: boolean; // New prop
  moduleError?: string; // New prop
}

const XSSVulnerabilities = ({ xss, isTested, moduleError }: XSSVulnerabilitiesProps) => {
  if (!isTested) return null;

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
      case 'high': return 'bg-red-500/20 text-red-600 dark:text-red-400 border-red-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-600 dark:text-yellow-400 border-yellow-500/30';
      case 'low': return 'bg-blue-500/20 text-blue-600 dark:text-blue-400 border-blue-500/30';
      default: return 'bg-muted/20 text-muted-foreground border-border';
    }
  };

  const hasData = !!xss && (xss.testedPayloads > 0 || xss.vulnerabilities.length > 0);

  return (
    <ModuleCardWrapper
      title="XSS Vulnerability Scan"
      icon={xss?.vulnerable ? AlertTriangle : Shield}
      iconColorClass={xss?.vulnerable ? 'text-red-500 dark:text-red-400' : 'text-green-500 dark:text-green-400'}
      moduleError={moduleError}
      hasData={hasData}
      noDataMessage="XSS scan not performed or no vulnerabilities detected."
    >
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-muted rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Status</p>
            <Badge className={xss?.vulnerable ? 'bg-red-500/20 text-red-600 dark:text-red-400 border-red-500/30' : 'bg-green-500/20 text-green-600 dark:text-green-400 border-green-500/30'}>
              {xss?.vulnerable ? 'VULNERABLE' : 'SECURE'}
            </Badge>
          </div>
          <div className="bg-muted rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Payloads Tested</p>
            <p className="text-2xl font-bold text-primary">{xss?.testedPayloads}</p>
          </div>
          <div className="bg-muted rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Vulnerabilities Found</p>
            <p className="text-2xl font-bold text-red-500 dark:text-red-400">{xss?.vulnerabilities.length}</p>
          </div>
        </div>

        {xss?.vulnerabilities && xss.vulnerabilities.length > 0 ? (
          <>
            <Alert variant="destructive" className="bg-destructive/10 border-destructive/50">
              <Lightbulb className="h-4 w-4" />
              <AlertDescription>
                <div className="font-semibold mb-2 text-destructive dark:text-red-400">🛡️ Mitigation Recommendations:</div>
                <ul className="list-disc list-inside space-y-1 text-destructive-foreground dark:text-red-300 text-sm">
                  <li>Encode all user input before rendering (HTML, JavaScript, URL encoding)</li>
                  <li>Implement Content Security Policy (CSP) headers</li>
                  <li>Use HTTPOnly and Secure flags on all cookies</li>
                  <li>Sanitize HTML input with libraries like DOMPurify</li>
                  <li>Validate and whitelist input on both client and server side</li>
                  <li>Avoid using dangerous functions like eval(), innerHTML, document.write()</li>
                  <li>Use modern frameworks with built-in XSS protection (React, Vue, Angular)</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-destructive dark:text-red-400 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Detected Vulnerabilities
              </h4>
              <div className="space-y-3">
                {xss.vulnerabilities.map((vuln, index) => (
                <div key={index} className="bg-muted rounded-lg p-4 border border-destructive/50">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex gap-2">
                      <Badge className={getSeverityColor(vuln.severity)}>
                        {vuln.severity.toUpperCase()}
                      </Badge>
                      {vuln.type && (
                        <Badge className="bg-muted/50 text-muted-foreground border-border">
                          {vuln.type}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Code className="h-3 w-3 text-muted-foreground/70" />
                        <span className="text-xs text-muted-foreground">Payload:</span>
                      </div>
                      <p className="text-foreground font-mono bg-muted/50 p-2 rounded break-all">
                        {vuln.payload}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Location:</p>
                      <p className="text-yellow-600 dark:text-yellow-400 break-words">{vuln.location}</p>
                    </div>
                    {vuln.evidence && (
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Evidence:</p>
                        <p className="text-foreground bg-muted/50 p-2 rounded font-mono break-all">
                          {vuln.evidence}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div className="bg-green-500/10 border border-green-500/50 rounded-lg p-4">
            <p className="text-green-600 dark:text-green-400 text-sm flex items-center gap-2">
              <Shield className="h-4 w-4" />
              No XSS vulnerabilities detected
            </p>
          </div>
        )}
      </CardContent>
    </ModuleCardWrapper>
  );
};

export default XSSVulnerabilities;